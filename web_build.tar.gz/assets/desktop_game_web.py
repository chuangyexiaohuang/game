"""Star Dodger - Web/Mobile version with touch controls.

Run desktop:  python desktop_game_web.py
Run web:      pygbag desktop_game_web.py
"""

import asyncio
import math
import random
import sys
from dataclasses import dataclass

import pygame


WIDTH = 920
HEIGHT = 620
FPS = 60
PLAYER_SPEED = 380
BACKGROUND = (8, 14, 28)
PANEL = (17, 29, 52)
WHITE = (240, 246, 255)
MUTED = (147, 169, 201)
CYAN = (66, 224, 235)
PINK = (255, 90, 154)
YELLOW = (255, 215, 106)

# --- detect if running in pygbag (web) ---
ON_WEB = sys.platform == "emscripten"


def make_font(size: int, bold: bool = False) -> pygame.font.Font:
    """Create a font that works on both desktop and web."""
    if ON_WEB:
        return pygame.font.Font(None, size)
    else:
        name = "Arial"
        if bold:
            return pygame.font.SysFont(name, size, bold=True)
        return pygame.font.SysFont(name, size)


@dataclass
class Asteroid:
    x: float
    y: float
    radius: float
    speed: float
    angle: float
    spin: float


@dataclass
class Bullet:
    x: float
    y: float
    speed: float = 720


@dataclass
class Particle:
    x: float
    y: float
    dx: float
    dy: float
    life: float
    size: float
    color: tuple[int, int, int]


class VirtualJoystick:
    """On-screen virtual joystick for mobile touch."""

    def __init__(self, cx: int, cy: int, outer_r: int, inner_r: int):
        self.cx = cx
        self.cy = cy
        self.outer_r = outer_r
        self.inner_r = inner_r
        self.active = False
        self.touch_id: object = None  # finger/mouse id
        self.dx = 0.0
        self.dy = 0.0

    def handle_down(self, pos: tuple[float, float], touch_id: object) -> bool:
        """Return True if touch is inside the joystick area."""
        dx = pos[0] - self.cx
        dy = pos[1] - self.cy
        if math.hypot(dx, dy) <= self.outer_r + 30:
            self.active = True
            self.touch_id = touch_id
            self._update(pos)
            return True
        return False

    def handle_move(self, pos: tuple[float, float], touch_id: object) -> None:
        if self.active and self.touch_id == touch_id:
            self._update(pos)

    def handle_up(self, touch_id: object) -> None:
        if self.touch_id == touch_id:
            self.active = False
            self.touch_id = None
            self.dx = 0.0
            self.dy = 0.0

    def _update(self, pos: tuple[float, float]) -> None:
        dx = pos[0] - self.cx
        dy = pos[1] - self.cy
        dist = math.hypot(dx, dy)
        if dist > 0:
            # clamp to outer radius, normalize to [-1, 1]
            clamped = min(dist, self.outer_r) / self.outer_r
            self.dx = (dx / dist) * clamped
            self.dy = (dy / dist) * clamped
        else:
            self.dx = 0.0
            self.dy = 0.0

    def draw(self, screen: pygame.Surface) -> None:
        # outer ring
        alpha_surface = pygame.Surface((self.outer_r * 2 + 20, self.outer_r * 2 + 20), pygame.SRCALPHA)
        ox, oy = self.outer_r + 10, self.outer_r + 10
        pygame.draw.circle(alpha_surface, (255, 255, 255, 35), (ox, oy), self.outer_r)
        pygame.draw.circle(alpha_surface, (255, 255, 255, 55), (ox, oy), self.outer_r, 2)
        # inner thumb
        tx = ox + int(self.dx * self.outer_r)
        ty = oy + int(self.dy * self.outer_r)
        pygame.draw.circle(alpha_surface, (200, 220, 255, 120), (tx, ty), self.inner_r)
        screen.blit(alpha_surface, (self.cx - ox, self.cy - oy))


class VirtualButton:
    """On-screen tap button for mobile."""

    def __init__(self, cx: int, cy: int, radius: int, label: str):
        self.cx = cx
        self.cy = cy
        self.radius = radius
        self.label = label
        self.pressed = False
        self.touch_id: object = None

    def handle_down(self, pos: tuple[float, float], touch_id: object) -> bool:
        if math.hypot(pos[0] - self.cx, pos[1] - self.cy) <= self.radius + 20:
            self.pressed = True
            self.touch_id = touch_id
            return True
        return False

    def handle_up(self, touch_id: object) -> None:
        if self.touch_id == touch_id:
            self.pressed = False
            self.touch_id = None

    def draw(self, screen: pygame.Surface) -> None:
        r2 = self.radius + 10
        alpha_surface = pygame.Surface((r2 * 2, r2 * 2), pygame.SRCALPHA)
        cx, cy = r2, r2
        if self.pressed:
            pygame.draw.circle(alpha_surface, (255, 90, 154, 80), (cx, cy), self.radius + 6)
        pygame.draw.circle(alpha_surface, (255, 90, 154, 50), (cx, cy), self.radius)
        pygame.draw.circle(alpha_surface, (255, 255, 255, 80), (cx, cy), self.radius, 3)
        # label
        font = make_font(22, bold=True)
        text = font.render(self.label, True, (255, 255, 255, 180))
        tr = text.get_rect(center=(cx, cy))
        alpha_surface.blit(text, tr)
        screen.blit(alpha_surface, (self.cx - cx, self.cy - cy))


class StarDodger:
    def __init__(self) -> None:
        pygame.init()
        pygame.display.set_caption("Star Dodger")
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.font_small = make_font(18)
        self.font_medium = make_font(28, bold=True)
        self.font_large = make_font(58, bold=True)
        self.stars = [
            [
                random.randrange(WIDTH),
                random.randrange(HEIGHT),
                random.choice((1, 1, 1, 2, 2, 3)),
                random.uniform(25, 150),
            ]
            for _ in range(100)
        ]
        self.best_score = 0
        self.running = True
        self.reset()

        # --- virtual controls (only shown on web/mobile) ---
        self.joystick = VirtualJoystick(110, HEIGHT - 110, 65, 28)
        self.fire_btn = VirtualButton(WIDTH - 110, HEIGHT - 110, 48, "FIRE")
        self.show_virtual_controls = ON_WEB
        self._touch_registry: dict[object, str] = {}  # track which control owns which touch

        if ON_WEB:
            self.state = "menu"
        else:
            self.state = "menu"

    def reset(self) -> None:
        self.player_x = WIDTH / 2
        self.player_y = HEIGHT - 92
        self.score = 0.0
        self.stage = 1
        self.spawn_timer = 0.0
        self.shot_timer = 0.0
        self.asteroids: list[Asteroid] = []
        self.bullets: list[Bullet] = []
        self.particles: list[Particle] = []

    def start(self) -> None:
        self.reset()
        self.state = "playing"

    def spawn_asteroid(self) -> None:
        radius = random.uniform(18, 42)
        speed = random.uniform(150, 225) + self.stage * 24
        self.asteroids.append(
            Asteroid(
                x=random.uniform(radius, WIDTH - radius),
                y=-radius - 10,
                radius=radius,
                speed=speed,
                angle=random.uniform(0, math.tau),
                spin=random.uniform(-2.2, 2.2),
            )
        )

    def explode(self, x: float | None = None, y: float | None = None, count: int = 65) -> None:
        x = self.player_x if x is None else x
        y = self.player_y if y is None else y
        for _ in range(count):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(50, 290)
            self.particles.append(
                Particle(
                    x,
                    y,
                    math.cos(angle) * speed,
                    math.sin(angle) * speed,
                    random.uniform(0.35, 0.95),
                    random.uniform(2, 6),
                    random.choice((CYAN, PINK, YELLOW, WHITE)),
                )
            )

    def shoot(self) -> None:
        self.bullets.append(Bullet(self.player_x, self.player_y - 28))
        self.shot_timer = 0.18

    def collide(self, asteroid: Asteroid) -> bool:
        distance = math.hypot(asteroid.x - self.player_x, asteroid.y - self.player_y)
        return distance < asteroid.radius + 15

    def handle_events(self) -> None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            # --- touch / mouse for virtual controls ---
            if self.show_virtual_controls:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = event.pos
                    fid = "mouse"
                    if self.fire_btn.handle_down(pos, fid):
                        self._touch_registry[fid] = "fire"
                        if self.state == "playing" and self.shot_timer == 0:
                            self.shoot()
                    elif self.joystick.handle_down(pos, fid):
                        self._touch_registry[fid] = "joy"
                    elif self.state in {"menu", "game_over"}:
                        self.start()
                    elif self.state == "paused":
                        self.state = "playing"

                elif event.type == pygame.MOUSEBUTTONUP:
                    fid = "mouse"
                    self.joystick.handle_up(fid)
                    self.fire_btn.handle_up(fid)
                    self._touch_registry.pop(fid, None)

                elif event.type == pygame.MOUSEMOTION:
                    fid = "mouse"
                    self.joystick.handle_move(event.pos, fid)
                    # check if dragging into fire button
                    if self.fire_btn.handle_down(event.pos, fid) and self._touch_registry.get(fid) != "fire":
                        self._touch_registry[fid] = "fire"
                        if self.state == "playing" and self.shot_timer == 0:
                            self.shoot()

                # --- real multi-touch events ---
                elif event.type == pygame.FINGERDOWN:
                    fx = event.x * WIDTH
                    fy = event.y * HEIGHT
                    fid = event.finger_id
                    if self.fire_btn.handle_down((fx, fy), fid):
                        self._touch_registry[fid] = "fire"
                        if self.state == "playing" and self.shot_timer == 0:
                            self.shoot()
                    elif self.joystick.handle_down((fx, fy), fid):
                        self._touch_registry[fid] = "joy"
                    elif self.state in {"menu", "game_over"}:
                        self.start()
                    elif self.state == "paused":
                        self.state = "playing"

                elif event.type == pygame.FINGERUP:
                    fid = event.finger_id
                    self.joystick.handle_up(fid)
                    self.fire_btn.handle_up(fid)
                    self._touch_registry.pop(fid, None)

                elif event.type == pygame.FINGERMOTION:
                    fx = event.x * WIDTH
                    fy = event.y * HEIGHT
                    fid = event.finger_id
                    self.joystick.handle_move((fx, fy), fid)

            # --- keyboard events (always available) ---
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                elif event.key == pygame.K_SPACE:
                    if self.state in {"menu", "game_over"}:
                        self.start()
                    elif self.state == "paused":
                        self.state = "playing"
                elif event.key == pygame.K_p:
                    if self.state == "playing":
                        self.state = "paused"
                    elif self.state == "paused":
                        self.state = "playing"
                elif event.key == pygame.K_r and self.state == "game_over":
                    self.start()
                elif event.key == pygame.K_m:
                    # toggle virtual controls on desktop
                    if not ON_WEB:
                        self.show_virtual_controls = not self.show_virtual_controls

    def update_stars(self, dt: float) -> None:
        for star in self.stars:
            star[1] += star[3] * dt
            if star[1] > HEIGHT:
                star[0] = random.randrange(WIDTH)
                star[1] = 0

    def update_particles(self, dt: float) -> None:
        alive = []
        for particle in self.particles:
            particle.life -= dt
            particle.x += particle.dx * dt
            particle.y += particle.dy * dt
            particle.dx *= 0.98
            particle.dy *= 0.98
            if particle.life > 0:
                alive.append(particle)
        self.particles = alive

    def update(self, dt: float) -> None:
        self.update_stars(dt)
        self.update_particles(dt)
        if self.state != "playing":
            return

        # combine keyboard + virtual joystick
        keys = pygame.key.get_pressed()
        kx = int(keys[pygame.K_RIGHT] or keys[pygame.K_d]) - int(
            keys[pygame.K_LEFT] or keys[pygame.K_a]
        )
        ky = int(keys[pygame.K_DOWN] or keys[pygame.K_s]) - int(
            keys[pygame.K_UP] or keys[pygame.K_w]
        )

        # merge virtual joystick input
        if abs(self.joystick.dx) > 0.1 or abs(self.joystick.dy) > 0.1:
            if abs(self.joystick.dx) > abs(kx):
                kx = self.joystick.dx
            if abs(self.joystick.dy) > abs(ky):
                ky = self.joystick.dy

        move_x = kx
        move_y = ky
        if move_x and move_y:
            move_x *= 0.7071
            move_y *= 0.7071
        self.player_x = max(30, min(WIDTH - 30, self.player_x + move_x * PLAYER_SPEED * dt))
        self.player_y = max(150, min(HEIGHT - 30, self.player_y + move_y * PLAYER_SPEED * dt))

        self.shot_timer = max(0.0, self.shot_timer - dt)
        key_fire = keys[pygame.K_SPACE] or keys[pygame.K_f] or keys[pygame.K_j]
        if (key_fire or self.fire_btn.pressed) and self.shot_timer == 0 and self.state == "playing":
            self.shoot()

        self.score += dt * 10
        self.stage = 1 + int(self.score // 120)
        self.spawn_timer -= dt
        if self.spawn_timer <= 0:
            self.spawn_asteroid()
            self.spawn_timer = max(0.2, 0.74 - self.stage * 0.045)

        active_bullets = []
        for bullet in self.bullets:
            bullet.y -= bullet.speed * dt
            hit = next(
                (
                    asteroid
                    for asteroid in self.asteroids
                    if math.hypot(asteroid.x - bullet.x, asteroid.y - bullet.y)
                    < asteroid.radius + 6
                ),
                None,
            )
            if hit is not None:
                self.asteroids.remove(hit)
                self.score += 35
                self.explode(hit.x, hit.y, 22)
            elif bullet.y > 110:
                active_bullets.append(bullet)
        self.bullets = active_bullets

        remaining = []
        for asteroid in self.asteroids:
            asteroid.y += asteroid.speed * dt
            asteroid.angle += asteroid.spin * dt
            if self.collide(asteroid):
                self.explode()
                self.best_score = max(self.best_score, int(self.score))
                self.state = "game_over"
                continue
            if asteroid.y < HEIGHT + asteroid.radius:
                remaining.append(asteroid)
        self.asteroids = remaining

    def draw_text(
        self,
        text: str,
        font: pygame.font.Font,
        color: tuple[int, int, int],
        center: tuple[float, float],
    ) -> None:
        surface = font.render(text, True, color)
        rect = surface.get_rect(center=center)
        self.screen.blit(surface, rect)

    def draw_asteroid(self, asteroid: Asteroid) -> None:
        points = []
        for index in range(10):
            angle = asteroid.angle + index * math.tau / 10
            wobble = asteroid.radius * (0.83 + 0.14 * math.sin(index * 5.17))
            points.append(
                (
                    asteroid.x + math.cos(angle) * wobble,
                    asteroid.y + math.sin(angle) * wobble,
                )
            )
        pygame.draw.polygon(self.screen, (104, 80, 105), points)
        pygame.draw.polygon(self.screen, PINK, points, 2)
        pygame.draw.circle(
            self.screen,
            (55, 42, 63),
            (int(asteroid.x - asteroid.radius * 0.2), int(asteroid.y - asteroid.radius * 0.1)),
            max(3, int(asteroid.radius * 0.23)),
        )

    def draw_ship(self) -> None:
        x, y = self.player_x, self.player_y
        flame = [(x - 8, y + 18), (x, y + random.uniform(28, 40)), (x + 8, y + 18)]
        pygame.draw.polygon(self.screen, (255, 118, 80), flame)
        body = [(x, y - 25), (x - 20, y + 20), (x, y + 13), (x + 20, y + 20)]
        pygame.draw.polygon(self.screen, (211, 241, 255), body)
        pygame.draw.polygon(self.screen, CYAN, body, 2)
        pygame.draw.circle(self.screen, (30, 92, 137), (int(x), int(y - 2)), 7)

    def draw_background(self) -> None:
        self.screen.fill(BACKGROUND)
        for x, y, size, _speed in self.stars:
            shade = 120 + min(size * 38, 110)
            pygame.draw.circle(self.screen, (shade, shade, 255), (int(x), int(y)), size)

        pygame.draw.rect(self.screen, PANEL, (0, 0, WIDTH, 104))
        pygame.draw.line(self.screen, (38, 79, 116), (0, 104), (WIDTH, 104), 2)
        self.draw_text("STAR DODGER", self.font_medium, WHITE, (122, 36))
        self.draw_text("SURVIVE THE FIELD", self.font_small, CYAN, (122, 66))
        self.draw_text(f"SCORE  {int(self.score):04d}", self.font_medium, WHITE, (WIDTH - 145, 34))
        self.draw_text(f"BEST  {self.best_score:04d}     LEVEL {self.stage}", self.font_small, MUTED, (WIDTH - 145, 66))

    def draw_overlay(self) -> None:
        if self.state == "playing":
            return
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((3, 8, 18, 188))
        self.screen.blit(overlay, (0, 0))

        if self.state == "menu":
            self.draw_text("STAR DODGER", self.font_large, WHITE, (WIDTH / 2, 235))
            self.draw_text("Dodge asteroids. Last as long as you can.", self.font_medium, CYAN, (WIDTH / 2, 295))
            if ON_WEB or self.show_virtual_controls:
                self.draw_text("DRAG JOYSTICK TO MOVE   TAP FIRE TO SHOOT", self.font_small, MUTED, (WIDTH / 2, 350))
            else:
                self.draw_text("ARROWS / WASD MOVE    SPACE / F / J FIRE", self.font_small, MUTED, (WIDTH / 2, 350))
            self.draw_text("P to pause    ESC to quit", self.font_small, MUTED, (WIDTH / 2, 380))
            self.draw_text("TAP TO START", self.font_medium, YELLOW, (WIDTH / 2, 440))
        elif self.state == "paused":
            self.draw_text("PAUSED", self.font_large, WHITE, (WIDTH / 2, 290))
            self.draw_text("Tap or press SPACE / P to continue", self.font_medium, CYAN, (WIDTH / 2, 350))
        elif self.state == "game_over":
            self.draw_text("SHIP LOST", self.font_large, PINK, (WIDTH / 2, 250))
            self.draw_text(f"FINAL SCORE  {int(self.score):04d}", self.font_medium, WHITE, (WIDTH / 2, 312))
            self.draw_text("Tap or press SPACE / R to try again", self.font_medium, YELLOW, (WIDTH / 2, 380))

    def draw(self) -> None:
        self.draw_background()
        for asteroid in self.asteroids:
            self.draw_asteroid(asteroid)
        for bullet in self.bullets:
            pygame.draw.line(
                self.screen,
                (175, 255, 255),
                (int(bullet.x), int(bullet.y + 10)),
                (int(bullet.x), int(bullet.y - 14)),
                4,
            )
            pygame.draw.circle(self.screen, CYAN, (int(bullet.x), int(bullet.y - 14)), 5)
        for particle in self.particles:
            alpha = max(0, min(255, int(particle.life * 270)))
            particle_surface = pygame.Surface((16, 16), pygame.SRCALPHA)
            pygame.draw.circle(
                particle_surface,
                (*particle.color, alpha),
                (8, 8),
                max(1, int(particle.size)),
            )
            self.screen.blit(particle_surface, (particle.x - 8, particle.y - 8))
        if self.state in {"playing", "paused"}:
            self.draw_ship()
        self.draw_overlay()

        # --- draw virtual controls on top ---
        if self.show_virtual_controls:
            self.joystick.draw(self.screen)
            self.fire_btn.draw(self.screen)

        pygame.display.flip()

    async def run(self) -> None:
        while self.running:
            dt = min(self.clock.tick(FPS) / 1000, 0.05)
            self.handle_events()
            self.update(dt)
            self.draw()
            if ON_WEB:
                await asyncio.sleep(0)
        pygame.quit()


async def main() -> None:
    game = StarDodger()
    await game.run()


if __name__ == "__main__":
    asyncio.run(main())
