"""Star Dodger DX - 大学生勇闯期末 豪华版
Enhanced with: levels, particles, power-ups, boss fights, optimized loading
"""

import asyncio
import math
import random
import sys
from dataclasses import dataclass
import pygame

WIDTH = 920
HEIGHT = 620
FPS = 60
PLAYER_SPEED = 380
BACKGROUND = (8, 14, 28)
PANEL = (17, 29, 52)
WHITE = (240, 246, 255)
MUTED = (147, 169, 201)
CYAN = (66, 224, 235)
PINK = (255, 90, 154)
YELLOW = (255, 215, 106)
ORANGE = (255, 160, 50)
GREEN = (80, 255, 120)
PURPLE = (180, 100, 255)
ON_WEB = sys.platform == "emscripten"

@dataclass
class Asteroid:
    x: float; y: float; radius: float; speed: float
    angle: float; spin: float; book_type: int = 0

@dataclass
class Bullet:
    x: float; y: float; speed: float = 720

@dataclass
class Particle:
    x: float; y: float; dx: float; dy: float
    life: float; size: float; color: tuple; decay: float = 0.98

@dataclass
class Dragon:
    x: float; y: float; speed: float
    hp: int = 2; max_hp: int = 2; shoot_timer: float = 0.0
    phase: int = 0; hit_flash: float = 0.0

@dataclass
class EnemyBullet:
    x: float; y: float; dx: float; dy: float

@dataclass
class PowerUp:
    x: float; y: float; kind: str
    vy: float = 80; timer: float = 0.0

@dataclass
class MiniEnemy:
    x: float; y: float; speed: float; hp: int = 1
    angle: float = 0.0; hit_flash: float = 0.0


class Joystick:
    def __init__(self, cx, cy, outer_r, inner_r):
        self.cx, self.cy = cx, cy
        self.outer_r, self.inner_r = outer_r, inner_r
        self.active = False; self.touch_id = None
        self.dx = self.dy = 0.0
    def handle_down(self, pos, tid):
        if math.hypot(pos[0]-self.cx, pos[1]-self.cy) <= self.outer_r + 30:
            self.active = True; self.touch_id = tid
            self._update(pos); return True
        return False
    def handle_move(self, pos, tid):
        if self.active and self.touch_id == tid: self._update(pos)
    def handle_up(self, tid):
        if self.touch_id == tid:
            self.active = False; self.touch_id = None; self.dx = self.dy = 0.0
    def _update(self, pos):
        dx, dy = pos[0]-self.cx, pos[1]-self.cy
        dist = math.hypot(dx, dy)
        if dist > 0:
            c = min(dist, self.outer_r) / self.outer_r
            self.dx, self.dy = (dx/dist)*c, (dy/dist)*c
    def draw(self, screen):
        r = self.outer_r + 10
        s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
        ox = oy = r
        pygame.draw.circle(s, (255,255,255,30), (ox,oy), self.outer_r)
        pygame.draw.circle(s, (255,255,255,50), (ox,oy), self.outer_r, 2)
        tx = ox + int(self.dx*self.outer_r)
        ty = oy + int(self.dy*self.outer_r)
        pygame.draw.circle(s, (200,220,255,110), (tx,ty), self.inner_r)
        screen.blit(s, (self.cx-ox, self.cy-oy))


class FireButton:
    def __init__(self, cx, cy, radius):
        self.cx, self.cy = cx, cy; self.radius = radius
        self.pressed = False; self.touch_id = None
    def handle_down(self, pos, tid):
        if math.hypot(pos[0]-self.cx, pos[1]-self.cy) <= self.radius + 30:
            self.pressed = True; self.touch_id = tid; return True
        return False
    def handle_up(self, tid):
        if self.touch_id == tid: self.pressed = False; self.touch_id = None
    def draw(self, screen, font):
        r = self.radius + 10
        s = pygame.Surface((r*2, r*2), pygame.SRCALPHA)
        cx = cy = r
        if self.pressed:
            pygame.draw.circle(s, (255,90,154,80), (cx,cy), self.radius+6)
        pygame.draw.circle(s, (255,90,154,50), (cx,cy), self.radius)
        pygame.draw.circle(s, (255,255,255,80), (cx,cy), self.radius, 3)
        text = font.render("射击", True, WHITE)
        tr = text.get_rect(center=(cx, cy))
        s.blit(text, tr)
        screen.blit(s, (self.cx-cx, self.cy-cy))


class StarDodger:
    def __init__(self):
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("大学生勇闯期末 DX")
        self.clock = pygame.time.Clock()
        if ON_WEB:
            self.f18 = pygame.font.Font("font.ttf", 18)
            self.f22 = pygame.font.Font("font.ttf", 22)
            self.f28 = pygame.font.Font("font.ttf", 28)
            self.f42 = pygame.font.Font("font.ttf", 42)
            self.f58 = pygame.font.Font("font.ttf", 58)
        else:
            self.f18 = pygame.font.SysFont("pingfang sc", 18)
            self.f22 = pygame.font.SysFont("pingfang sc", 22)
            self.f28 = pygame.font.SysFont("pingfang sc", 28)
            self.f42 = pygame.font.SysFont("pingfang sc", 42)
            self.f58 = pygame.font.SysFont("pingfang sc", 58)
        self.stars = [[random.randrange(WIDTH), random.randrange(HEIGHT),
            random.choice((1,1,1,2,2,3,3,4)),
            random.uniform(15, 180), random.uniform(0.5, 1.5)] for _ in range(160)]
        self.nebula = self._make_nebula()
        self.best_score = 0
        self.running = True
        self.book_imgs = self._load_imgs()
        self.bullet_img = self._load_bullet()
        self.dragon_img = self._load_dragon()
        self.joystick = Joystick(140, HEIGHT-140, 95, 42)
        self.fire_btn = FireButton(WIDTH-140, HEIGHT-140, 72)
        self.show_vcontrols = ON_WEB
        self._touch_reg = {}
        self.reset()
        self.state = "menu"
        self._shake_timer = 0.0
        self._shake_intensity = 0.0
        self._combo = 0
        self._combo_timer = 0.0

    def _make_nebula(self):
        surf = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for _ in range(80):
            cx = random.randrange(WIDTH); cy = random.randrange(HEIGHT)
            radius = random.randint(80, 200)
            color = random.choice([(20,10,40,30),(10,20,40,25),(30,10,30,28),(15,15,45,35)])
            s = pygame.Surface((radius*2, radius*2), pygame.SRCALPHA)
            pygame.draw.circle(s, color, (radius, radius), radius)
            surf.blit(s, (cx-radius, cy-radius))
        return surf

    def _load_imgs(self):
        imgs = []
        for bf in ["book1.png","book2.png","book3.png","book4.png"]:
            try: imgs.append(pygame.image.load(bf).convert_alpha())
            except: s=pygame.Surface((120,140),pygame.SRCALPHA); s.fill((60,60,80,220)); imgs.append(s)
        return imgs

    def _load_bullet(self):
        try:
            img = pygame.image.load("p1.png").convert_alpha()
            return pygame.transform.smoothscale(pygame.transform.rotate(img, 180), (14, 18))
        except: return None

    def _load_dragon(self):
        try:
            raw = pygame.image.load("奶龙.jpg").convert()
            surf = pygame.Surface(raw.get_size(), pygame.SRCALPHA)
            surf.blit(raw, (0,0)); surf.set_colorkey((255,255,255))
            return surf
        except: return None

    def reset(self):
        self.player_x = WIDTH/2; self.player_y = HEIGHT-92
        self.score = 0.0; self.stage = 1; self.level = 1
        self.spawn_timer = 0.0; self.shot_timer = 0.0
        self.player_hp = 100; self.max_hp = 100
        self.asteroids = []; self.bullets = []; self.particles = []
        self.dragons = []; self.enemy_bullets = []; self.mini_enemies = []; self.powerups = []
        self.kills = [0,0,0,0]; self._celebrated = [False]*4
        self.shield_charges = 0; self._shield_earned = 0; self._prev_min = 0
        self.popup_text = ""; self.popup_timer = 0.0
        self._combo = 0; self._combo_timer = 0.0
        self.wave_count = 0; self.wave_enemies_left = 0
        self.boss_active = False
        self._speed_pup = 0.0; self._rapid_pup = 0.0

    def start(self):
        self.reset(); self.state = "playing"
        self.popup_text = "第一关·初入大学"; self.popup_timer = 2.0

    def spawn_asteroid(self):
        r = random.uniform(18, 42)
        sp = random.uniform(150, 225) + self.stage * 24 + self.level * 10
        self.asteroids.append(Asteroid(x=random.uniform(r,WIDTH-r), y=-r-10,
            radius=r, speed=sp, angle=random.uniform(0,math.tau), spin=random.uniform(-2.2,2.2),
            book_type=random.randint(0,3)))

    def spawn_mini_enemy(self):
        self.mini_enemies.append(MiniEnemy(x=random.uniform(40,WIDTH-40), y=-30,
            speed=random.uniform(130,180)+self.level*15, hp=1))

    def spawn_dragon_boss(self):
        self.dragons.append(Dragon(x=WIDTH//2, y=-80, speed=50,
            hp=3+self.level, max_hp=3+self.level, shoot_timer=1.0, phase=0))

    def spawn_powerup(self, x, y):
        self.powerups.append(PowerUp(x=x, y=y, kind=random.choice(["speed","rapid","shield","bomb"])))

    def explode(self, x=None, y=None, count=65):
        x=self.player_x if x is None else x; y=self.player_y if y is None else y
        for _ in range(count):
            a=random.uniform(0,math.tau); sp=random.uniform(50,290)
            self.particles.append(Particle(x,y,math.cos(a)*sp,math.sin(a)*sp,
                random.uniform(0.35,0.95), random.uniform(2,7), random.choice([CYAN,PINK,YELLOW,WHITE,ORANGE])))

    def screen_shake(self, intensity=8, duration=0.2):
        self._shake_timer=duration; self._shake_intensity=intensity

    def shoot(self):
        m=min(self.kills); base=1 if m<5 else 2+(m-5)//10
        count=base*2 if self._rapid_pup>0 else base
        spacing=22
        for i in range(count):
            self.bullets.append(Bullet(self.player_x+(i-(count-1)/2)*spacing, self.player_y-28))
        self.shot_timer=0.10 if self._rapid_pup>0 else 0.18

    def handle_events(self):
        for event in pygame.event.get():
            if event.type==pygame.QUIT: self.running=False
            if self.show_vcontrols:
                if event.type==pygame.MOUSEBUTTONDOWN:
                    self._handle_tap(event.pos,"mouse")
                elif event.type==pygame.MOUSEBUTTONUP:
                    self.joystick.handle_up("mouse"); self.fire_btn.handle_up("mouse")
                    self._touch_reg.pop("mouse",None)
                elif event.type==pygame.MOUSEMOTION:
                    self.joystick.handle_move(event.pos,"mouse")
                elif event.type==pygame.FINGERDOWN:
                    self._handle_tap((event.x*WIDTH,event.y*HEIGHT),event.finger_id)
                elif event.type==pygame.FINGERUP:
                    fid=event.finger_id; self.joystick.handle_up(fid); self.fire_btn.handle_up(fid)
                    self._touch_reg.pop(fid,None)
                elif event.type==pygame.FINGERMOTION:
                    self.joystick.handle_move((event.x*WIDTH,event.y*HEIGHT),event.finger_id)
            if event.type==pygame.KEYDOWN:
                k=event.key
                if k==pygame.K_ESCAPE: self.running=False
                elif k==pygame.K_SPACE:
                    if self.state in ("menu","game_over","victory"): self.start()
                    elif self.state=="paused": self.state="playing"
                elif k==pygame.K_p:
                    if self.state=="playing": self.state="paused"
                    elif self.state=="paused": self.state="playing"
                elif k==pygame.K_r and self.state in ("game_over","victory"): self.start()
                elif k==pygame.K_m and not ON_WEB: self.show_vcontrols=not self.show_vcontrols

    def _handle_tap(self, pos, fid):
        if self.fire_btn.handle_down(pos,fid):
            self._touch_reg[fid]="fire"
            if self.state=="playing" and self.shot_timer==0: self.shoot(); return True
        if self.joystick.handle_down(pos,fid):
            self._touch_reg[fid]="joy"; return True
        if self.state in ("menu","game_over","victory"): self.start()
        elif self.state=="paused": self.state="playing"
        return False

    def update(self, dt):
        if self._shake_timer>0: self._shake_timer-=dt
        for s in self.stars:
            s[1]+=s[3]*dt
            if s[1]>HEIGHT: s[0]=random.randrange(WIDTH); s[1]=0
        self.particles=[p for p in self.particles if p.life>0]
        for p in self.particles:
            p.life-=dt; p.x+=p.dx*dt; p.y+=p.dy*dt; p.dx*=p.decay; p.dy*=p.decay
        if self._speed_pup>0: self._speed_pup-=dt
        if self._rapid_pup>0: self._rapid_pup-=dt
        if self._combo_timer>0:
            self._combo_timer-=dt
            if self._combo_timer<=0: self._combo=0
        if self.state!="playing": return

        keys=pygame.key.get_pressed()
        kx=int(keys[pygame.K_RIGHT] or keys[pygame.K_d])-int(keys[pygame.K_LEFT] or keys[pygame.K_a])
        ky=int(keys[pygame.K_DOWN] or keys[pygame.K_s])-int(keys[pygame.K_UP] or keys[pygame.K_w])
        if abs(self.joystick.dx)>0.1 or abs(self.joystick.dy)>0.1:
            if abs(self.joystick.dx)>abs(kx): kx=self.joystick.dx
            if abs(self.joystick.dy)>abs(ky): ky=self.joystick.dy
        if kx and ky: kx*=0.7071; ky*=0.7071
        speed=PLAYER_SPEED*(1.5 if self._speed_pup>0 else 1)
        self.player_x=max(30,min(WIDTH-30,self.player_x+kx*speed*dt))
        self.player_y=max(150,min(HEIGHT-30,self.player_y+ky*speed*dt))

        self.shot_timer=max(0.0,self.shot_timer-dt)
        if (keys[pygame.K_SPACE] or keys[pygame.K_f] or keys[pygame.K_j] or self.fire_btn.pressed) and self.shot_timer==0:
            self.shoot()

        self.score+=dt*10; self.stage=1+int(self.score//120)
        old_lv=self.level; self.level=1+int(self.score//200)
        if self.level>old_lv and self.state=="playing" and old_lv>0:
            names=["","第一关·初入大学","第二关·期中考试","第三关·论文答辩","第四关·实习挑战","第五关·期末决战"]
            self.popup_text=names[min(self.level,len(names)-1)]; self.popup_timer=2.0

        self.spawn_timer-=dt
        if self.spawn_timer<=0:
            if self.wave_enemies_left<=0 and not self.boss_active:
                self.wave_count+=1
                if self.wave_count%5==0:
                    self.boss_active=True; self.spawn_dragon_boss()
                    self.popup_text="⚠ BOSS来袭！⚠"; self.popup_timer=2.0; self.spawn_timer=3.0
                else:
                    self.wave_enemies_left=3+self.level; self.spawn_timer=0.3
            if self.wave_enemies_left>0:
                self.spawn_asteroid(); self.wave_enemies_left-=1
                if random.random()<0.15+self.level*0.02: self.spawn_mini_enemy()
                self.spawn_timer=max(0.15,0.6-self.stage*0.03)

        alive_b=[]
        for b in self.bullets:
            b.y-=b.speed*dt
            hit=next((a for a in self.asteroids if math.hypot(a.x-b.x,a.y-b.y)<max(80,a.radius*2.25)),None)
            if hit:
                self.asteroids.remove(hit); self.score+=35
                self._combo+=1; self._combo_timer=2.0
                if self.kills[hit.book_type]<100:
                    self.kills[hit.book_type]+=1
                    if self.kills[hit.book_type]==100 and not self._celebrated[hit.book_type]:
                        self._celebrated[hit.book_type]=True
                        books=["高等数学","C语言程序设计","大学英语","面向对象程序设计"]
                        self.popup_text=f"恭喜你{books[hit.book_type]}满绩啦！"; self.popup_timer=3.0
                self.explode(hit.x,hit.y,22); self.screen_shake(4,0.1)
                if random.random()<0.08: self.spawn_powerup(hit.x,hit.y)
            elif b.y>110:
                hd=next((d for d in self.dragons if abs(d.x-b.x)<50 and abs(d.y-b.y)<50),None)
                if hd:
                    hd.hp-=1; hd.hit_flash=0.1; self.explode(b.x,b.y,10); self.screen_shake(3,0.08)
                    if hd.hp<=0:
                        self.dragons.remove(hd); self.boss_active=False
                        self.score+=200; self.explode(hd.x,hd.y,60); self.screen_shake(12,0.4)
                        self.popup_text="击败BOSS！+200分"; self.popup_timer=2.0
                        for _ in range(3): self.spawn_powerup(hd.x+random.uniform(-40,40),hd.y)
                else:
                    hm=next((m for m in self.mini_enemies if abs(m.x-b.x)<30 and abs(m.y-b.y)<30),None)
                    if hm:
                        hm.hp-=1; hm.hit_flash=0.1
                        if hm.hp<=0: self.mini_enemies.remove(hm); self.score+=50; self.explode(hm.x,hm.y,15); self.screen_shake(3,0.08)
                    else: alive_b.append(b)
        self.bullets=alive_b

        m=min(self.kills)
        if m>=5 and self._prev_min<5: self.popup_text="子弹升级了！"; self.popup_timer=1.5
        elif m>self._prev_min and (m-5)%10==0 and m>self._prev_min//10*10: self.popup_text="子弹升级了！"; self.popup_timer=1.5
        new_e=m//10
        if new_e>self._shield_earned:
            g=new_e-self._shield_earned; self._shield_earned=new_e; self.shield_charges+=g
            self.popup_text=f"获得护盾x{g}！" if g>1 else "获得护盾！"; self.popup_timer=1.5
        self._prev_min=m
        if self.popup_timer>0: self.popup_timer-=dt
        if min(self.kills)>=100 and self.state=="playing":
            self.popup_text="🎉 全部满绩！恭喜通关！🎉"; self.popup_timer=5.0; self.state="victory"

        if self.state=="playing":
            for d in self.dragons[:]:
                d.y+=d.speed*dt; d.hit_flash=max(0,d.hit_flash-dt); d.shoot_timer-=dt
                hp_r=d.hp/d.max_hp
                d.phase=2 if hp_r<0.33 else 1 if hp_r<0.66 else 0
                if d.shoot_timer<=0 and d.y>80:
                    dx=self.player_x-d.x; dy=self.player_y-d.y; dist=math.hypot(dx,dy)
                    if dist>0:
                        sp=220+d.phase*60
                        if d.phase>=1:
                            for off in [-0.15,0,0.15]:
                                a=math.atan2(dy,dx)+off
                                self.enemy_bullets.append(EnemyBullet(d.x,d.y+40,math.cos(a)*sp,math.sin(a)*sp))
                        else:
                            self.enemy_bullets.append(EnemyBullet(d.x,d.y+40,dx/dist*sp,dy/dist*sp))
                    d.shoot_timer=random.uniform(1.0,2.5)-d.phase*0.3
                if d.y>HEIGHT+100: self.dragons.remove(d); self.boss_active=False
            for b in self.enemy_bullets[:]:
                b.x+=b.dx*dt; b.y+=b.dy*dt
                if b.y<-20 or b.y>HEIGHT+20 or b.x<-20 or b.x>WIDTH+20: self.enemy_bullets.remove(b); continue
                if math.hypot(b.x-self.player_x,b.y-self.player_y)<20:
                    if self.shield_charges>0: self.shield_charges-=1; self.enemy_bullets.remove(b); self.popup_text="护盾抵消！"; self.popup_timer=1.0
                    else:
                        self.player_hp-=20; self.enemy_bullets.remove(b); self.explode(b.x,b.y,10); self._combo=0
                        if self.player_hp<=0: self.explode(); self.screen_shake(15,0.5); self.best_score=max(self.best_score,int(self.score)); self.state="game_over"
            for m in self.mini_enemies[:]:
                m.y+=m.speed*dt; m.hit_flash=max(0,m.hit_flash-dt); m.angle+=dt*2
                if math.hypot(m.x-self.player_x,m.y-self.player_y)<25:
                    if self.shield_charges>0: self.shield_charges-=1; self.mini_enemies.remove(m); self.popup_text="护盾抵消！"; self.popup_timer=1.0
                    else: self.player_hp-=30; self.mini_enemies.remove(m); self.explode(m.x,m.y,20)
                    if self.player_hp<=0: self.explode(); self.screen_shake(15,0.5); self.best_score=max(self.best_score,int(self.score)); self.state="game_over"
                elif m.y>HEIGHT+50: self.mini_enemies.remove(m)
            for p in self.powerups[:]:
                p.y+=p.vy*dt; p.timer+=dt
                if p.y>HEIGHT+30: self.powerups.remove(p); continue
                if math.hypot(p.x-self.player_x,p.y-self.player_y)<30:
                    self.powerups.remove(p)
                    if p.kind=="speed": self._speed_pup=5.0; self.popup_text="速度提升！"; self.popup_timer=1.0
                    elif p.kind=="rapid": self._rapid_pup=5.0; self.popup_text="速射模式！"; self.popup_timer=1.0
                    elif p.kind=="shield": self.shield_charges+=1; self.popup_text="+1护盾！"; self.popup_timer=1.0
                    elif p.kind=="bomb":
                        for a in self.asteroids: self.score+=15; self.explode(a.x,a.y,5)
                        self.asteroids.clear()
                        for m in self.mini_enemies: self.score+=20; self.explode(m.x,m.y,8)
                        self.mini_enemies.clear()
                        self.screen_shake(15,0.5); self.popup_text="💥全屏清除！"; self.popup_timer=1.5

        for a in self.asteroids[:]:
            a.y+=a.speed*dt; a.angle+=a.spin*dt
            if math.hypot(a.x-self.player_x,a.y-self.player_y)<max(80,a.radius*2.25)+15:
                if self.shield_charges>0:
                    self.shield_charges-=1; self.popup_text="护盾抵消！"; self.popup_timer=1.0
                    self.explode(a.x,a.y,20); self.screen_shake(3,0.08)
                else:
                    self.player_hp-=40; self.explode(a.x,a.y,15); self._combo=0
                    if self.player_hp<=0: self.explode(); self.screen_shake(15,0.5); self.best_score=max(self.best_score,int(self.score)); self.state="game_over"
                continue
            if a.y<HEIGHT+max(80,a.radius*2.25): continue
            self.asteroids.remove(a)

    def draw_text(self,text,font,color,center):
        s=font.render(text,True,color); self.screen.blit(s,s.get_rect(center=center))

    def draw(self):
        shake=[0.0, 0.0]
        if self._shake_timer>0:
            shake[0]=random.uniform(-self._shake_intensity,self._shake_intensity)
            shake[1]=random.uniform(-self._shake_intensity,self._shake_intensity)
        self.screen.fill(BACKGROUND); self.screen.blit(self.nebula,(0,0))
        for x,y,sz,spd,bri in self.stars:
            sh=int(80+bri*120); c=(sh,sh,min(255,sh+20))
            pygame.draw.circle(self.screen,c,(int(x+shake[0]),int(y+shake[1])),sz)
        pygame.draw.rect(self.screen,PANEL,(shake[0],shake[1],WIDTH,104))
        pygame.draw.line(self.screen,(38,79,116),(shake[0],104+shake[1]),(WIDTH+shake[0],104+shake[1]),2)
        self.draw_text("大学生勇闯期末 DX",self.f28,WHITE,(140+shake[0],34+shake[1]))
        books_full=["高数","C语言","英语","OOP"]
        start_x=WIDTH//2-140
        for i in range(4):
            cx=start_x+i*120
            icon=pygame.transform.smoothscale(self.book_imgs[i],(30,30))
            self.screen.blit(icon,icon.get_rect(center=(cx+shake[0],32+shake[1])))
            self.draw_text(f"{books_full[i]}:{self.kills[i]}",self.f18,CYAN,(cx+shake[0],80+shake[1]))
        self.draw_text(f"Lv.{self.level} 得分:{int(self.score)}",self.f18,YELLOW,(WIDTH-120+shake[0],24+shake[1]))
        if self._combo>1 and self._combo_timer>0:
            cc=(255,200,50) if self._combo<10 else (255,100,100)
            self.draw_text(f"连击x{self._combo}",self.f22,cc,(WIDTH-120+shake[0],50+shake[1]))
        if self.shield_charges>0:
            self.draw_text(f"才华附体 x{self.shield_charges}",self.f18,(150,220,255),(WIDTH-70+shake[0],80+shake[1]))
        py=130
        if self._speed_pup>0: self.draw_text(f"⚡加速 {self._speed_pup:.0f}s",self.f18,CYAN,(60+shake[0],py+shake[1])); py+=22
        if self._rapid_pup>0: self.draw_text(f"🔥速射 {self._rapid_pup:.0f}s",self.f18,YELLOW,(60+shake[0],py+shake[1]))
        for a in self.asteroids:
            src=self.book_imgs[a.book_type]; s=max(160,int(a.radius*4.5))
            scaled=pygame.transform.smoothscale(src,(s,s))
            rotated=pygame.transform.rotate(scaled,math.degrees(a.angle)%360)
            self.screen.blit(rotated,rotated.get_rect(center=(a.x+shake[0],a.y+shake[1])))
        for b in self.bullets:
            if self.bullet_img:
                self.screen.blit(self.bullet_img,self.bullet_img.get_rect(center=(b.x+shake[0],b.y+shake[1])))
            else:
                x,y=int(b.x+shake[0]),int(b.y+shake[1])
                pygame.draw.line(self.screen,(175,255,255),(x,y+10),(x,y-14),4)
                pygame.draw.circle(self.screen,CYAN,(x,y-14),5)
        for p in self.particles:
            a=max(0,min(255,int(p.life*270)))
            ps=pygame.Surface((14,14),pygame.SRCALPHA)
            pygame.draw.circle(ps,(*p.color,a),(7,7),max(1,int(p.size)))
            self.screen.blit(ps,(p.x+shake[0]-7,p.y+shake[1]-7))
        for d in self.dragons:
            if self.dragon_img:
                s=80; sc=pygame.transform.smoothscale(self.dragon_img,(s,s))
                if d.hit_flash>0:
                    fl=pygame.Surface(sc.get_size(),pygame.SRCALPHA); fl.fill((255,255,255,180))
                    sc.blit(fl,(0,0))
                r=sc.get_rect(center=(d.x+shake[0],d.y+shake[1])); self.screen.blit(sc,r)
                bw,bh=60,8; bx,by=d.x+shake[0]-bw//2,d.y+shake[1]-55
                pygame.draw.rect(self.screen,(60,60,60),(bx,by,bw,bh),border_radius=3)
                hp_w=int(bw*d.hp/d.max_hp); hp_c=(255,80,80) if d.hp<d.max_hp//3+1 else (255,200,50)
                pygame.draw.rect(self.screen,hp_c,(bx,by,hp_w,bh),border_radius=3)
                if d.max_hp>2: self.draw_text("BOSS",self.f18,(255,80,80),(d.x+shake[0],d.y+shake[1]-68))
        for m in self.mini_enemies:
            x,y=int(m.x+shake[0]),int(m.y+shake[1])
            c=(255,100,100) if m.hit_flash>0 else (200,50,50)
            pygame.draw.circle(self.screen,c,(x,y),12); pygame.draw.circle(self.screen,(255,200,200),(x,y),6)
            for off in [-0.5,0.5]:
                wx=x+int(math.cos(m.angle+off)*18); wy=y+int(math.sin(m.angle+off)*18)
                pygame.draw.line(self.screen,(180,80,80),(x,y),(wx,wy),3)
        for eb in self.enemy_bullets:
            x,y=int(eb.x+shake[0]),int(eb.y+shake[1])
            pygame.draw.circle(self.screen,(255,220,50),(x,y),6); pygame.draw.circle(self.screen,(255,255,100),(x,y),3)
        for p in self.powerups:
            x,y=int(p.x+shake[0]),int(p.y+shake[1])
            pulse=math.sin(p.timer*4)*4; r=16+pulse
            s=pygame.Surface((int(r*2),int(r*2)),pygame.SRCALPHA)
            c={"speed":CYAN,"rapid":YELLOW,"shield":(150,220,255),"bomb":ORANGE}[p.kind]
            pygame.draw.circle(s,(*c,150),(r,r),r); pygame.draw.circle(s,(255,255,255,120),(r,r),r,2)
            self.screen.blit(s,(x-r,y-r))
        if self.state in ("playing","paused"):
            x,y=self.player_x+shake[0],self.player_y+shake[1]
            pygame.draw.polygon(self.screen,(255,118,80),[(x-8,y+16),(x,y+random.uniform(22,34)),(x+8,y+16)])
            txt=self.f28.render("大学生",True,(255,255,100)); tr=txt.get_rect(center=(x,y))
            glow=self.f28.render("大学生",True,CYAN)
            for dx,dy in [(-1,-1),(1,-1),(-1,1),(1,1)]: self.screen.blit(glow,tr.move(dx,dy))
            self.screen.blit(txt,tr)
            hp_r=self.player_hp/self.max_hp; hp_c=(80,255,80) if hp_r>0.5 else (255,200,50) if hp_r>0.25 else (255,60,60)
            bw,bh=60,8; bx,by=x-bw//2,y+30
            pygame.draw.rect(self.screen,(40,40,40),(bx,by,bw,bh),border_radius=3)
            pygame.draw.rect(self.screen,hp_c,(bx,by,int(bw*hp_r),bh),border_radius=3)
            self.screen.blit(self.f18.render(f"HP:{self.player_hp}",True,WHITE),self.f18.get_rect(center=(x,y+48)))
        if self.shield_charges>0 and self.state in ("playing","paused"):
            x,y=self.player_x+shake[0],self.player_y+shake[1]
            sr=40+int(math.sin(pygame.time.get_ticks()*0.005)*5)
            ss=pygame.Surface((sr*2,sr*2),pygame.SRCALPHA)
            a=min(120,40+self.shield_charges*20)
            pygame.draw.circle(ss,(100,200,255,a),(sr,sr),sr)
            pygame.draw.circle(ss,(150,220,255,a+40),(sr,sr),sr,2)
            self.screen.blit(ss,(x-sr,y-sr))
        if self.state!="playing":
            ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((3,8,18,188)); self.screen.blit(ov,(0,0))
            if self.state=="menu":
                self.draw_text("大学生勇闯期末 DX",self.f58,WHITE,(WIDTH/2,210))
                self.draw_text("击败科目获得升级 每5关BOSS战",self.f28,CYAN,(WIDTH/2,270))
                self.draw_text("💡拾取道具: ⚡加速 🔥速射 🛡护盾 💥清屏",self.f18,MUTED,(WIDTH/2,315))
                h="摇杆+射击" if (ON_WEB or self.show_vcontrols) else "方向键移动 空格开火"
                self.draw_text(h,self.f22,MUTED,(WIDTH/2,360))
                self.draw_text(f"最高分: {self.best_score}",self.f22,YELLOW,(WIDTH/2,405))
                self.draw_text("点击开始",self.f28,YELLOW,(WIDTH/2,460))
            elif self.state=="paused":
                self.draw_text("已暂停",self.f58,WHITE,(WIDTH/2,290)); self.draw_text("点击继续",self.f28,CYAN,(WIDTH/2,360))
            elif self.state=="game_over":
                self.draw_text("大学生坠机",self.f58,PINK,(WIDTH/2,230))
                self.draw_text(f"得分 {int(self.score):04d} Lv.{self.level}",self.f28,WHITE,(WIDTH/2,300))
                if self._combo>5: self.draw_text(f"最高连击 x{self._combo}",self.f22,ORANGE,(WIDTH/2,340))
                self.draw_text("点击重新开始",self.f28,YELLOW,(WIDTH/2,400))
            elif self.state=="victory":
                self.draw_text("🎉 恭喜通关！🎉",self.f58,YELLOW,(WIDTH/2,210))
                self.draw_text("全部课程满绩毕业！",self.f28,CYAN,(WIDTH/2,270))
                self.draw_text(f"总击杀 {sum(self.kills)} 最终Lv.{self.level}",self.f28,WHITE,(WIDTH/2,320))
                self.draw_text("点击再来一局",self.f28,YELLOW,(WIDTH/2,400))
        if self.show_vcontrols: self.joystick.draw(self.screen); self.fire_btn.draw(self.screen,self.f22)
        if self.popup_timer>0:
            a=min(255,int(self.popup_timer*200))
            is_big="满绩" in self.popup_text or "通关" in self.popup_text or "BOSS" in self.popup_text
            font=self.f58 if is_big else self.f42
            if "满绩" in self.popup_text or "通关" in self.popup_text: color=(255,215,0)
            elif "BOSS" in self.popup_text: color=(255,80,80)
            else: color=(255,255,100)
            popup=font.render(self.popup_text,True,color); popup.set_alpha(a)
            self.screen.blit(popup,popup.get_rect(center=(WIDTH//2+shake[0],HEIGHT//2+shake[1]-30)))
        pygame.display.flip()

async def main():
    pygame.init()
    game=StarDodger()
    while game.running:
        dt=min(game.clock.tick(FPS)/1000,0.05)
        game.handle_events(); game.update(dt); game.draw()
        await asyncio.sleep(0)
    pygame.quit()

asyncio.run(main())
